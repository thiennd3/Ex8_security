create
    definer = root@localhost procedure get_top_sale(IN top_number int)
BEGIN
    select  id,name,sale_number,description
  from product
  order by sale_number desc limit top_number  offset 0;
-- store proceduce trả về top n sản phẩm bán chạy--
END;

