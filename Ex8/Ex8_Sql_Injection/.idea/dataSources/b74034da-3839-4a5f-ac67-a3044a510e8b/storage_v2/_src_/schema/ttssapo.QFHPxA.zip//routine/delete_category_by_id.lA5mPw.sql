create
    definer = root@localhost procedure delete_category_by_id(IN category_id int)
BEGIN
				declare result int;
                
                
                if  not exists (select * from category where id= category_id) then
                -- trả về 0 khi mã danh mục không tồn tại 
				set @result=0 ;
                else 	
						start transaction;
								begin
									DECLARE exit HANDLER FOR sqlexception
									set @result=1 ;
									-- trả về 1 khi  không xóa được sản phẩm với mã danh mục truyền vào
									delete from product
												where product.category_id=category_id;    
									-- trả về 2 khi không xóa được danh mục
									set @result=2 ;
									delete from category 
												where id=category_id;
									-- trả về 3 tức là đã xóa thành công
									set @result=3 ;

									commit;
									end;
					end if;
				select @result;
END;

